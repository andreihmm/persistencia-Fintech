﻿using System.Configuration;
using System.Data;
using System.Windows;
using UVVFintech.control;
using UVVFintech.model;
using UVVFintech.persistencia;

namespace UVVFintech
{
    /// <summary>
    /// Interaction logic for App.xaml
    /// </summary>
    public partial class App : Application
    {
        public static GerenciadorDeClientes? GerenciadorDeClientes { get; private set; }
        public static GerenciadorDeContas? GerenciadorDeContas { get; private set; }

        public static Conta? ContaEmUso { get; set; }

        protected override void OnStartup(StartupEventArgs e)
        {
            base.OnStartup(e);

            // Inicializa o Gerenciador de Clientes e carrega os clientes do BD
            GerenciadorDeClientes = new GerenciadorDeClientes();

            // Inicializa o Gerenciador de Contas passando os clientes já carregados
            GerenciadorDeContas = new GerenciadorDeContas(GerenciadorDeClientes.retornarTodosClientes());

            ContaEmUso = null;
        }

    }


}
