﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text.Json;
using UVVFintech.model;

namespace UVVFintech.persistencia
{
    public class BD
    {
        private List<Cliente> clientes;

        public BD()
        {
            clientes = new List<Cliente>();
            retornarBD(); // Carregar clientes do arquivo ao inicializar
        }

        public void salvarBD(Cliente cliente)
        {
            if (cliente != null)
            {
                // Verifique se o cliente já existe na lista
                var clienteExistente = clientes.FirstOrDefault(c => c.CPF == cliente.CPF);
                if (clienteExistente != null)
                {
                    // Atualiza as informações do cliente existente
                    var index = clientes.IndexOf(clienteExistente);
                    clientes[index] = cliente;
                }
                else
                {
                    // Se o cliente não existe, adiciona-o
                    clientes.Add(cliente);
                }

                // Salva a lista de clientes atualizada no arquivo JSON
                var jsonData = JsonSerializer.Serialize(clientes);
                File.WriteAllText("clientes.json", jsonData);
            }
        }

        public List<Cliente> retornarBD()
        {
            if (File.Exists("clientes.json"))
            {
                var jsonData = File.ReadAllText("clientes.json");
                clientes = JsonSerializer.Deserialize<List<Cliente>>(jsonData) ?? new List<Cliente>(); // Inicializa se for nulo
            }
            return clientes;
        }


        public Cliente retornarBD(String CPF)
        {
            return clientes.FirstOrDefault(c => c.CPF == CPF);
        }

        public void removerBD(String CPF)
        {
            var cliente = clientes.FirstOrDefault(c => c.CPF == CPF);
            if (cliente != null)
            {
                clientes.Remove(cliente);
                var jsonData = JsonSerializer.Serialize(clientes);
                File.WriteAllText("clientes.json", jsonData);
            }
        }

        public bool existe(String CPF)
        {
            return clientes.Any(c => c.CPF == CPF);
        }

        public void adicionarContaAoCliente(string cpf, Conta conta)
        {
            var cliente = retornarBD(cpf);
            if (cliente != null)
            {
                // Verifica se já existe uma conta com o mesmo ID
                var contaExistente = cliente.Contas.FirstOrDefault(c => c.Id == conta.Id);
                if (contaExistente != null)
                {
                    // Se a conta já existe, atualize-a
                    var index = cliente.Contas.IndexOf(contaExistente);
                    cliente.Contas[index] = conta;
                }
                else
                {
                    // Caso contrário, adicione a nova conta
                    cliente.adicionarConta(conta);
                }

                // Atualiza o arquivo JSON com a conta modificada
                var jsonData = JsonSerializer.Serialize(clientes);
                File.WriteAllText("clientes.json", jsonData);
            }
        }



    }
}
