﻿using System;

namespace UVVFintech.model
{
    public class Corrente : Conta
    {

        public override string Tipo => "Corrente";

        public const double TaxaJuros = 0.1;

        public Corrente(Cliente titular, int id, double saldo = 0) : base(id, saldo)
        {
        }

        public Corrente() : base() { }


        public double Taxa { get; } = TaxaJuros;

        public override void CobrarTaxa()
        {
            if (GetSaldo() > 0)
            {
                double taxaCobrada = GetSaldo() * Taxa;
                Sacar(taxaCobrada);
                Console.WriteLine($"Taxa de {taxaCobrada} cobrada do saldo.");
            }
            else
            {
                Console.WriteLine("Saldo insuficiente para cobrança de taxa.");
            }
        }
    }
}
