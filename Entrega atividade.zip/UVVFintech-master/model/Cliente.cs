﻿using System;
using System.Collections.Generic;
using UVVFintech.control;

namespace UVVFintech.model
{
    public class Cliente
    {
        public string Nome { get; set; }
        public string CPF { get; set; }
        public DateTime DataNascimento { get; set; }

        // Propriedade para armazenar as contas do cliente
        public List<Conta> Contas { get; set; }

        public GerenciadorDeTransacoes gerenciadorDeTransacoes { get; set; }

        public string senha { get; set; }

        public Cliente()
        {
            Contas = new List<Conta>();
        }

        public Cliente(string nome, string cpf, DateTime dataNascimento)
        {
            Nome = nome;
            CPF = cpf;
            DataNascimento = dataNascimento;
            Contas = new List<Conta>();
        }

        public Cliente(string nome, string cpf, DateTime dataNascimento, string senha)
        {
            Nome = nome;
            CPF = cpf;
            DataNascimento = dataNascimento;
            Contas = new List<Conta>();
            gerenciadorDeTransacoes = new GerenciadorDeTransacoes();
            senha = senha;
        }



        public void adicionarConta(Conta conta)
        {
            if (Contas == null)
            {
                Contas = new List<Conta>(); // Inicializa a lista se estiver nula
            }
            Contas.Add(conta);
        }

        public List<Conta> getContas()
        {
            return Contas;
        }

    }
}
