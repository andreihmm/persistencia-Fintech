﻿using System;
using System.Text.Json;
using System.Text.Json.Serialization;
using UVVFintech.model;

public class ContaConverter : JsonConverter<Conta>
{
    public override Conta Read(ref Utf8JsonReader reader, Type typeToConvert, JsonSerializerOptions options)
    {
        using (JsonDocument doc = JsonDocument.ParseValue(ref reader))
        {
            JsonElement root = doc.RootElement;

            // Verifique se o campo "Tipo" existe
            if (!root.TryGetProperty("Tipo", out JsonElement tipoElement))
            {
                throw new JsonException("Campo 'Tipo' não encontrado no JSON.");
            }

            string tipoConta = tipoElement.GetString();

            // Escolha a classe correta para desserializar com base no valor de "Tipo"
            return tipoConta switch
            {
                "ContaCorrente" => JsonSerializer.Deserialize<Corrente>(root.GetRawText(), options),
                "ContaPoupanca" => JsonSerializer.Deserialize<Poupanca>(root.GetRawText(), options),
                _ => throw new NotSupportedException($"Tipo de conta não suportado: {tipoConta}")
            };
        }
    }

    public override void Write(Utf8JsonWriter writer, Conta value, JsonSerializerOptions options)
    {
        // Adicione o tipo de conta ao JSON
        writer.WriteStartObject();

        string tipoConta = value switch
        {
            Corrente => "ContaCorrente",
            Poupanca => "ContaPoupanca",
            _ => throw new NotSupportedException($"Tipo de conta não suportado: {value.GetType()}")
        };

        writer.WriteString("Tipo", tipoConta);

        // Serializa o restante do objeto
        var json = JsonSerializer.Serialize(value, value.GetType(), options);
        using (JsonDocument doc = JsonDocument.Parse(json))
        {
            foreach (var property in doc.RootElement.EnumerateObject())
            {
                property.WriteTo(writer);
            }
        }

        writer.WriteEndObject();
    }
}
