﻿using System;

namespace UVVFintech.model
{
    public class Poupanca : Conta
    {

        public override string Tipo => "Poupanca";

        public const double TaxaJuros = 0.1;

        public Poupanca(Cliente titular, int id, double saldo = 0) : base(id, saldo)
        {
        }

        public Poupanca() : base() { }

        public double Taxa { get; } = TaxaJuros;

        public override void CobrarTaxa()
        {
            if (GetSaldo() > 0)
            {
                double jurosAcumulados = GetSaldo() * Taxa;
                Depositar(jurosAcumulados);
                Console.WriteLine($"Juros de {jurosAcumulados} adicionados ao saldo.");
            }
            else
            {
                Console.WriteLine("Saldo insuficiente para cobrança de juros.");
            }
        }
    }
}
