﻿using System;
using System.Collections.Generic;
using Newtonsoft.Json;

namespace UVVFintech.model
{
    [JsonConverter(typeof(ContaConverter))] // Define o conversor JSON para a classe base
    public abstract class Conta
    {
        public abstract string Tipo { get; }
        public int Id { get; set; }
        public double Saldo { get; set; }

        public Conta()
        {
            Id = 0;
            Saldo = 0;
        }

        public Conta(int id, double saldo = 0)
        {
            Id = id;
            Saldo = saldo;
        }

        public abstract void CobrarTaxa();

        public bool Sacar(double valor)
        {
            if (valor > 0 && valor <= Saldo)
            {
                Saldo -= valor;
                return true;
            }
            return false;
        }

        public void Depositar(double valor)
        {
            if (valor > 0)
            {
                Saldo += valor;
                Console.WriteLine("Depósito realizado com sucesso.");
            }
            else
            {
                Console.WriteLine("Falha no depósito. O valor deve ser positivo.");
            }
        }

        public double GetSaldo()
        {
            return Saldo;
        }
    }
}
