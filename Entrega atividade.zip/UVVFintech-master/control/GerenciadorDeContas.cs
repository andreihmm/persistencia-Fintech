﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using UVVFintech.model;

namespace UVVFintech.control
{
    public class GerenciadorDeContas
    {
        private Conta modeloPersistenciaConta;

        public List<Conta> contaList;

        public GerenciadorDeContas(List<Cliente> clientes) // Recebe os clientes carregados do BD
        {
            contaList = new List<Conta>();

            foreach (var cliente in clientes)
            {
                if (cliente.getContas() != null)
                {
                    contaList.AddRange(cliente.getContas()); // Adiciona todas as contas de cada cliente
                }
            }
        }


        public void adicionarConta(Conta conta) { 
            contaList.Add(conta);
        }

        public void removerConta(Conta conta) {
            contaList.Remove(conta);
        }

        public Conta retornarConta(int id)
        {
            // Usando LINQ para encontrar a conta com o ID especificado
            return contaList.FirstOrDefault(conta => conta.Id == id);
        }

    }
}
