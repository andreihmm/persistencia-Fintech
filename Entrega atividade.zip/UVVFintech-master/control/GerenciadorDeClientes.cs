﻿using System;
using System.Collections.Generic;
using System.Linq;
using UVVFintech.model;
using UVVFintech.persistencia;

namespace UVVFintech.control
{
    public class GerenciadorDeClientes
    {
        private List<Cliente> clientes;
        public BD bancoDeDados;

        public GerenciadorDeClientes()
        {
            bancoDeDados = new BD();
            clientes = bancoDeDados.retornarBD() ?? new List<Cliente>(); // Carregar clientes do banco de dados ao inicializar
        }

        public void adicionarCliente(Cliente cliente)
        {
            clientes.Add(cliente);
            bancoDeDados.salvarBD(cliente); // Salvar o cliente no banco de dados
        }

        public void removerCliente(String cpf)
        {
            Cliente clienteARemover = clientes.FirstOrDefault(c => c.CPF == cpf);
            if (clienteARemover != null)
            {
                clientes.Remove(clienteARemover);
                bancoDeDados.removerBD(cpf); // Remover o cliente do banco de dados
            }
        }

        public List<Cliente> retornarTodosClientes()
        {
            return clientes;
        }

        public Cliente retornarCli(string cpf)
        {
            return clientes.FirstOrDefault(c => c.CPF == cpf);
        }
    }
}
