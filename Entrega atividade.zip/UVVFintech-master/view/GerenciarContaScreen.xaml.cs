﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using UVVFintech.control;
using UVVFintech.model;

namespace UVVFintech.View
{
    /// <summary>
    /// Lógica interna para GerenciarContaScreen.xaml
    /// </summary>
    public partial class GerenciarContaScreen : Window
    {
        public GerenciarContaScreen()
        {
            InitializeComponent();
            CarregarDadosNoDataGrid();
        }

        private void CarregarDadosNoDataGrid()
        {
            // Acesse a lista de contas do GerenciadorDeContas
            var contas = App.GerenciadorDeContas.contaList; // Usando a lista de contas do gerenciador
            DataGrid_Conta.ItemsSource = contas; // Define a fonte de dados do DataGrid
        }

        private void DataGrid_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            if (DataGrid_Conta.SelectedItem is Conta contaSelecionada)
            {
                MessageBox.Show($"Conta selecionada: {contaSelecionada.Id}");
            }
        }

        private void Button_CriarNovaConta_Click(object sender, RoutedEventArgs e)
        {
            var ownedWindow = new CriarContaScreen();
            ownedWindow.Owner = this;
            ownedWindow.Show();
            this.Visibility = Visibility.Hidden;
        }

        private void Button_Voltar_Click(object sender, RoutedEventArgs e)
        {
            var ownedWindow = new InicialGerenteScreen();
            ownedWindow.Owner = this;
            ownedWindow.Show();
            this.Visibility = Visibility.Hidden;
        }

        
    }
}
