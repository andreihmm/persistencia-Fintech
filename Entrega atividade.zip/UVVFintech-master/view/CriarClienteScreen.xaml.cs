﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using UVVFintech.control;
using UVVFintech.model;

namespace UVVFintech.View
{
    /// <summary>
    /// Lógica interna para CriarClienteScreen.xaml
    /// </summary>
    public partial class CriarClienteScreen : Window
    {
        public CriarClienteScreen()
        {
            InitializeComponent();
        }

        private void Button_Voltar_Click(object sender, RoutedEventArgs e)
        {
            var ownedWindow = new InicialGerenteScreen();
            ownedWindow.Owner = this;
            ownedWindow.Show();
            this.Visibility = Visibility.Hidden;
        }

        private void Button_AdicionarCliente_Click(object sender, RoutedEventArgs e)
        {
            // Captura as informações do cliente da interface gráfica
            string nome = TextBox_Nome.Text;
            string cpf = TextBox_CPF.Text;
            DateTime dataNascimento;
            if (DateTime.TryParse(TextBox_Nascimento.Text, out dataNascimento))
            {
                //        public Cliente(string nome, string cpf, DateTime dataNascimento, List<Conta> contas, GerenciadorDeTransacoes gerenciador, int senha)

                Cliente novoCliente = new(nome, cpf, dataNascimento, "0");
                App.GerenciadorDeClientes.adicionarCliente(novoCliente);


                MessageBox.Show("Cliente adicionado com sucesso!");
            }
            else
            {
                MessageBox.Show("Data de nascimento inválida. Por favor, insira uma data válida.");
            }

            var ownedWindow = new ContaScreen();
            ownedWindow.Owner = this;
            ownedWindow.Show();
            this.Visibility = Visibility.Hidden;
        }
    }
}
