﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using UVVFintech.control;
using UVVFintech.model;

namespace UVVFintech.View
{
    /// <summary>
    /// Lógica interna para CriarContaScreen.xaml
    /// </summary>
    public partial class CriarContaScreen : Window
    {

        public CriarContaScreen()
        {
            InitializeComponent();
        }
        private void Button_Salvar_Click(object sender, RoutedEventArgs e)
        {
            string cpf = TextBox_CPF.Text; // Obtém o CPF inserido
            int idConta;
            if (int.TryParse(TextBox_ID.Text, out idConta)) // Tenta converter o ID da conta para int
            {
                Cliente titular = App.GerenciadorDeClientes.retornarCli(cpf); // Verifica se o cliente com o CPF existe
                if (titular != null)
                {
                    // Verifica o tipo de conta selecionado
                    string tipoConta = (ComboBox_TipoConta.SelectedItem as ComboBoxItem)?.Content.ToString();
                    Conta novaConta = null;

                    double saldoInicial = 0; // Defina o saldo inicial, se necessário

                    if (tipoConta == "Corrente")
                    {
                        novaConta = new Corrente(titular, idConta, saldoInicial); // Cria uma Conta Corrente
                    }
                    else if (tipoConta == "Poupança")
                    {
                        novaConta = new Poupanca(titular, idConta, saldoInicial); // Cria uma Conta Poupança
                    }

                    if (novaConta != null)
                    {
                        titular.adicionarConta(novaConta); // Adiciona a conta ao cliente
                        App.GerenciadorDeClientes.bancoDeDados.adicionarContaAoCliente(cpf, novaConta); // Adiciona a conta ao banco de dados do cliente
                        MessageBox.Show("Conta criada com sucesso!");

                        App.ContaEmUso = novaConta;
                    }
                    else
                    {
                        MessageBox.Show("Por favor, selecione o tipo de conta.");
                    }
                }
                else
                {
                    MessageBox.Show("Cliente não encontrado. Verifique o CPF.");
                }
            }
            else
            {
                MessageBox.Show("ID da conta inválido. Por favor, insira um número.");
            }

            var ownedWindow = new ContaScreen();
            ownedWindow.Owner = this;
            ownedWindow.Show();
            this.Visibility = Visibility.Hidden;
        }




        private void TextBox_CPF_TextChanged(object sender, System.Windows.Controls.TextChangedEventArgs e)
        {
            // Aqui você pode adicionar a lógica que deseja executar quando o texto no TextBox_CPF mudar.
        }
    }
}
