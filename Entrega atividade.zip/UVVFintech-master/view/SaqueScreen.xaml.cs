﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.Json;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using System.IO; // Importando o namespace necessário

using UVVFintech.model;

namespace UVVFintech.View
{
    /// <summary>
    /// Lógica interna para SaqueScreen.xaml
    /// </summary>
    public partial class SaqueScreen : Window
    {
        public SaqueScreen()
        {
            InitializeComponent();
        }

        private void Button_Confirmar_Click(object sender, RoutedEventArgs e)
        {
            // Realiza a transação de saque
            Sacar s = new Sacar(conta: App.ContaEmUso);
            s.fazerTransacao(Convert.ToDouble(TextBox_Valor.Text));

        }

        private void AtualizarContasNoJson()
        {
            // Carregar a lista de clientes do JSON
            List<Cliente> clientes = App.GerenciadorDeClientes.bancoDeDados.retornarBD(); // Supondo que você tenha um método para ler do JSON

            // Encontrar o cliente correspondente na lista de clientes
            var cliente = clientes.FirstOrDefault(c => c.Contas.Any(cc => cc.Id == App.ContaEmUso.Id)); // Verifica se o cliente tem a conta em uso

            if (cliente != null)
            {
                // Encontrar a conta específica dentro do cliente
                var contaAtualizada = cliente.Contas.FirstOrDefault(c => c.Id == App.ContaEmUso.Id); // Busca a conta pela Id

                if (contaAtualizada != null)
                {
                    // Atualiza as informações da conta
                    contaAtualizada.Saldo = App.ContaEmUso.Saldo; // Atualiza o saldo conforme a conta em uso
                }
            }

            // Serializa a lista atualizada de clientes de volta para o JSON
            var jsonData = JsonSerializer.Serialize(clientes, new JsonSerializerOptions { WriteIndented = true });
            File.WriteAllText("clientes.json", jsonData); // Salva no arquivo JSON
        }


        private void Button_Voltar_Click(object sender, RoutedEventArgs e)
        {
            var ownedWindow = new TransacaoScreen();
            ownedWindow.Owner = this;
            ownedWindow.Show();
            this.Visibility = Visibility.Hidden;
        }
    }
}
